import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-add-show',
  templateUrl: './add-show.component.html',
  styleUrls: ['./add-show.component.css']
})
export class AddShowComponent implements OnInit {
  addShowForm:FormGroup
  errorMessage:String;  
  got:String;
  successMessage:String


  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.addShowForm=this.formBuilder.group(
      {
        movieName:['',Validators.required],
        theatreName:['',Validators.required],
        time:['',Validators.required],
        seatsAvailable:['',Validators.required]

      }
    )
  }

  addShowFunction(){
    this.errorMessage=null;
    this.successMessage=null;
    this.service.addShow(this.addShowForm.value).subscribe(response=>{
      this.successMessage=response["Show"];
    },err=>{
      this.errorMessage=err.error.message;
 
    })

  }

  back(){
    this.router.navigate(['/admin'])
   }

}
