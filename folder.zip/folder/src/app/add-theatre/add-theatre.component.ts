import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-add-theatre',
  templateUrl: './add-theatre.component.html',
  styleUrls: ['./add-theatre.component.css']
})
export class AddTheatreComponent implements OnInit {
  addTheatreForm:FormGroup
  errorMessage:String;  
  got:String;
  successMessage:String

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.addTheatreForm=this.formBuilder.group(
      {
        theatreName:['',Validators.required],
        location:['',Validators.required],
        seatingCapacity:['',Validators.required],
        rate:['',Validators.required]

      }
    )
  }

  addTheatreFunction(){
    this.errorMessage=null;
    this.successMessage=null;
    this.service.addTheatre(this.addTheatreForm.value).subscribe(response=>{
      this.successMessage=response["Theatre"];
    },err=>{
      this.errorMessage=err.error.message;
 
    })

  }

  back(){
    this.router.navigate(['/admin'])
  }

}
