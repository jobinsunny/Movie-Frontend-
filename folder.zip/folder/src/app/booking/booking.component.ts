import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  bookingForm:FormGroup
  errorMessage:String;
  successMessage:String;
  movieName: String;
  theatreName: String;
  time: String;
  userName: String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.movieName=sessionStorage.getItem("movieName");
    this.theatreName=sessionStorage.getItem("theatreName");
    this.time=sessionStorage.getItem("time");
    this.userName=localStorage.getItem("userName");
    console.log(this.userName);
    console.log(this.movieName);
    
    this.bookingForm=this.formBuilder.group(
      {
        userName:[this.userName,Validators.required],
        showTime:[this.time,Validators.required],
        
        movieName:[this.movieName,Validators.required],
        theatreName:[this.theatreName,Validators.required],
        seatsBooked:['',Validators.required],
        showDate:['',[Validators.required,this.dateValidate]]
      }
    )
  }
  

  booking(){
    this.errorMessage=null;
    this.successMessage=null;
    this.service.booking(this.bookingForm.value).subscribe(response=>{
      this.successMessage=response["booking"];
    },err=>{
      this.errorMessage=err.error.message;
 
    })

  }

  public dateValidate(showDate:FormControl){
    return new Date(showDate.value).setHours(0,0,0,0)>=new Date().setHours(0,0,0,0)? null:{
      dateError:{message:"Invalid date"}
    }
  }

  back(){
    this.router.navigate(['/users'])
  }


}
