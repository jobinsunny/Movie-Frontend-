import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-theatre',
  templateUrl: './delete-theatre.component.html',
  styleUrls: ['./delete-theatre.component.css']
})
export class DeleteTheatreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
