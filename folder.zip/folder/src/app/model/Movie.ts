export class Movie{
    movieName:string;
	 director:string;
	 genre:string;
	language:string;
}