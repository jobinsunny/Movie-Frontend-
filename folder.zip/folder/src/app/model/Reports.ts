export class Reports{
    bookingId:number;
	userName:string;
    movieName:string;
    theatreName:string;
    showTime:string;
    seatsBooked:number;
    showDate:string;
    totalPrice:number;
    status:string;

}
