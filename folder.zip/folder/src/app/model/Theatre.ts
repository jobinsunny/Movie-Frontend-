export class Theatre{
    theatreName:string;
	location:string;
    seatingCapacity:number;
    rate:number;
	
}

