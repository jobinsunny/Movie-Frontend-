import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-showsavl',
  templateUrl: './showsavl.component.html',
  styleUrls: ['./showsavl.component.css']
})
export class ShowsavlComponent implements OnInit {
  shows=[]
  errorMessage:String;
  successMessage: String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.service.getShow().subscribe(book=>{
      this.shows=book;
    },err=>{
      this.errorMessage=err.message;
    })
  }

  book(b){
    sessionStorage.setItem("movieName",b.movieName);
    sessionStorage.setItem("theatreName",b.theatreName);
    sessionStorage.setItem("time",b.time);
    this.router.navigate(['/booking']);
  }
  
  back(){
    this.router.navigate(['/users'])
  }


}
