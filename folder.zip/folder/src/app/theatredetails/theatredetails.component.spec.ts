import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TheatredetailsComponent } from './theatredetails.component';

describe('TheatredetailsComponent', () => {
  let component: TheatredetailsComponent;
  let fixture: ComponentFixture<TheatredetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TheatredetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TheatredetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
