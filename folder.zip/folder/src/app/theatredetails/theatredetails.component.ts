import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-theatredetails',
  templateUrl: './theatredetails.component.html',
  styleUrls: ['./theatredetails.component.css']
})
export class TheatredetailsComponent implements OnInit {
  theatrelist=[]
  errorMessage:String;

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit() {
    this.service.getTheatre().subscribe(response =>{
            this.theatrelist=response;
          },err=>{
            this.errorMessage=err.message;
    })
  }

  back(){
    this.router.navigate(['/users'])
  }

}
