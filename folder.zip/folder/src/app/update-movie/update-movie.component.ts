import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-update-movie',
  templateUrl: './update-movie.component.html',
  styleUrls: ['./update-movie.component.css']
})
export class UpdateMovieComponent implements OnInit {
  
  updateMovieForm:FormGroup
  successMessage:String
  errorMessage:String
  movieName: String;
  director: String;
  genre: String;
  language: String;
  



  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit(): void {
    this.updateMovieForm=this.formBuilder.group(
      {
        userName:[this.movieName,Validators.required],
        showingTime:[this.director,Validators.required],
        movieName:[this.genre,Validators.required],
        theatreName:[this.language,Validators.required]
      }
    )
    
  }

  updateMovieFunction(){
    this.service.updateMovie(this.updateMovieForm.value).subscribe(response=>
      {
this.successMessage=response["Movie"];
      },err=>
      {
this.errorMessage=err.error.message;
      })

  }

  back(){
    this.router.navigate(['/admin'])
  }

}
