import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit(): void {
  }

  back(){
    this.router.navigate(['/loginpage'])
  }

  movie(){
    this.router.navigate(['/moviedetails'])
  }

  theatre(){
    this.router.navigate(['/theatredetails'])
  }

  show(){
    this.router.navigate(['/showsavl'])
  }

  viewBooking(){
    this.router.navigate(['/viewBooking'])
  }  



}
