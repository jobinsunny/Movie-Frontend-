import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllserviceService } from '../allservice.service';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {
  reportList=[];
  errorMessage: string;
  successMessage: string;
  


  constructor(private formBuilder:FormBuilder, private router: Router,private service:AllserviceService) { }

  ngOnInit(){
    this.service.getReport().subscribe(response =>{
            this.reportList=response;
          },err=>{
            this.errorMessage=err.message;
    })

  }


  back(){
    this.router.navigate(['/admin'])
  }

    

}
